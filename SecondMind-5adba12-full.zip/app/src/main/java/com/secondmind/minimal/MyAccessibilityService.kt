package com.secondmind.minimal
import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
class MyAccessibilityService : AccessibilityService() {
  override fun onServiceConnected() {}
  override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
  override fun onInterrupt() {}
}
