
#!/usr/bin/env python3
import re, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
print(f"[patch006] repo root = {ROOT}")

# 1) Find MainActivity.kt
candidates = list(ROOT.glob("app/src/main/java/**/MainActivity.kt"))
if not candidates:
    print("[patch006] ERROR: Could not locate app/src/main/java/**/MainActivity.kt", file=sys.stderr)
    sys.exit(1)
ma_path = candidates[0]
print(f"[patch006] MainActivity = {ma_path}")

src = ma_path.read_text(encoding="utf-8")
orig = src

def find_block_span(s: str, open_brace_idx: int):
    depth = 0
    for i in range(open_brace_idx, len(s)):
        c = s[i]
        if c == '{':
            depth += 1
        elif c == '}':
            depth -= 1
            if depth == 0:
                return (open_brace_idx, i)
    return None

changed = False

# 2) Insert route composable("pulse") at end of first NavHost block (if missing)
if 'composable("pulse")' not in src:
    m = re.search(r'NavHost\s*\(', src)
    if m:
        brace = src.find('{', m.end())
        if brace != -1:
            span = find_block_span(src, brace)
            if span:
                _, end = span
                # indentation for closing line
                prev_nl = src.rfind('\n', 0, end)
                indent = re.match(r'\s*', src[prev_nl+1:end]).group(0)
                insertion = f'\n{indent}  composable("pulse") {{ com.secondmind.minimal.pulse.PulseScreen() }}\n'
                src = src[:end] + insertion + src[end:]
                changed = True
                print("[patch006] Inserted pulse route at end of NavHost.")
            else:
                print("[patch006] WARN: Could not match NavHost braces; route not inserted.")
    else:
        print("[patch006] WARN: No NavHost(...) found; route not inserted.")
else:
    print("[patch006] Route already present; skipping.")

# 3) Insert menu item inside first DropdownMenu block (if missing)
if 'Text("Pulse")' not in src:
    m = re.search(r'DropdownMenu\s*\(', src)
    if m:
        brace = src.find('{', m.end())
        if brace != -1:
            span = find_block_span(src, brace)
            if span:
                _, end = span
                prev_nl = src.rfind('\n', 0, end)
                indent = re.match(r'\s*', src[prev_nl+1:end]).group(0)
                menu = (
                    f'\n{indent}  DropdownMenuItem(text = {{ Text("Pulse") }}, onClick = {{\n'
                    f'{indent}    open = false\n'
                    f'{indent}    nav.navigate("pulse")\n'
                    f'{indent}  }})\n'
                )
                src = src[:end] + menu + src[end:]
                changed = True
                print("[patch006] Inserted Pulse menu item.")
            else:
                print("[patch006] WARN: Could not match DropdownMenu braces; menu not inserted.")
    else:
        print("[patch006] WARN: No DropdownMenu(...) found; menu not inserted.")
else:
    print("[patch006] Menu item already present; skipping.")

if changed:
    ma_path.write_text(src, encoding="utf-8")
    print("[patch006] Wrote updated MainActivity.kt")
else:
    print("[patch006] No changes applied to MainActivity.kt")

# 4) Ensure Pulse files exist and are compile-safe
pulse_dir = ROOT / "app/src/main/java/com/secondmind/minimal/pulse"
pulse_dir.mkdir(parents=True, exist_ok=True)

constellation = pulse_dir / "ConstellationMap.kt"
if not constellation.exists():
    constellation.write_text('''\
package com.secondmind.minimal.pulse

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

data class Node(val label: String, val x: Float, val y: Float, val r: Float)
data class Edge(val a: Int, val b: Int)

@Composable
fun ConstellationMap(nodes: List<Node>, edges: List[Edge]) {
    Canvas(modifier = Modifier.fillMaxWidth().height(220.dp)) {
        val cx = size.width / 2f
        val cy = size.height / 2f
        edges.forEach { e ->
            val n1 = nodes[e.a]; val n2 = nodes[e.b]
            drawLine(
                color = Color.Black,
                start = Offset(cx + n1.x, cy + n1.y),
                end = Offset(cx + n2.x, cy + n2.y),
                strokeWidth = 2f
            )
        }
        nodes.forEach { n ->
            drawCircle(
                color = Color.Black,
                radius = n.r,
                center = Offset(cx + n.x, cy + n.y)
            )
        }
    }
}
'''.replace('[', '<').replace(']', '>'), encoding="utf-8")
    print("[patch006] Wrote ConstellationMap.kt")

pulse = pulse_dir / "PulseScreen.kt"
if not pulse.exists():
    pulse.write_text('''\
package com.secondmind.minimal.pulse

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlin.math.abs
import java.util.concurrent.TimeUnit

data class Signal(val title: String, val priority: Int, val dueAt: Long?, val createdAt: Long)

@Composable
fun PulseScreen() {
    val now = System.currentTimeMillis()
    val signals = remember {
        listOf(
            Signal("Review open positions", 3, now + 2*60*60*1000, now - 6*60*60*1000),
            Signal("Astro window tonight", 2, now + 10*60*60*1000, now - 60*60*1000),
            Signal("Water reminder", 1, null, now - 30*60*1000),
            Signal("Read market brief", 1, now + 4*60*60*1000, now - 2*60*60*1000),
        ).sortedWith(compareByDescending<Signal> { it.priority }
            .thenBy { it.dueAt ?: Long.MAX_VALUE }
            .thenBy { it.createdAt })
    }

    var lastWhisperAt by remember { mutableStateOf(0L) }
    val whisper = remember(lastWhisperAt) {
        val elapsed = now - lastWhisperAt
        if (elapsed > TimeUnit.HOURS.toMillis(24)) "Tip: long-press a signal to snooze it."
        else null
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.Start
    ) {
        Text("Pulse — Top 3 Signals")
        Spacer(Modifier.height(8.dp))
        signals.take(3).forEach { s ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(Modifier.padding(12.dp)) {
                    Text("• ${s.title}")
                    Text("priority=${s.priority}  due=${s.dueAt?.let { friendlyEta(it - now) } ?: "—"}")
                }
            }
        }

        Spacer(Modifier.height(16.dp))
        if (whisper != null) {
            Card { Text(whisper, modifier = Modifier.padding(12.dp)) }
            lastWhisperAt = now
        }

        Spacer(Modifier.height(24.dp))
        Text("Constellation")
        Spacer(Modifier.height(8.dp))
        ConstellationMap(
            nodes = listOf(
                Node("You", 0f, 0f, 10f),
                Node("Trade", -60f, -10f, 6f),
                Node("Astro", 50f, -20f, 7f),
                Node("Health", -20f, 40f, 5f),
                Node("Learn", 40f, 30f, 5f),
            ),
            edges = list_of_edges()
        )
    }
}

private fun list_of_edges() = listOf(
    Edge(0,1), Edge(0,2), Edge(0,3), Edge(0,4),
    Edge(1,2), Edge(2,4)
)

private fun friendlyEta(deltaMs: Long): String {
    val absMs = abs(deltaMs)
    val h = absMs / (60*60*1000)
    val m = (absMs / (60*1000)) % 60
    val sign = if (deltaMs >= 0) "in " else ""
    return "$sign${h}h ${m}m"
}
''', encoding="utf-8")
    print("[patch006] Wrote PulseScreen.kt")

print("[patch006] Done. Now commit & push the changes.")
